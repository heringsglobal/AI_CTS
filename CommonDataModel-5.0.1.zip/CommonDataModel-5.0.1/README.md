Common-Data-Model
=================

See full CDM specification file on our [Wiki](http://www.ohdsi.org/web/wiki/doku.php?id=documentation:cdm:single-page) or in the [CDM V5 PDF](https://github.com/OHDSI/CommonDataModel/blob/master/OMOP%20CDM%20v5.pdf)
