Common-Data-Model / PostgreSQL
=================

This folder contains the SQL scripts for PostgreSQL. 

In order to create your instantiation of the Common Data Model, we recommend following these steps:

1. Create an empty schema.

2. Execute the script `CDM V4 ddl.sql` to create the tables and fields.

3. Load your data into the schema.

